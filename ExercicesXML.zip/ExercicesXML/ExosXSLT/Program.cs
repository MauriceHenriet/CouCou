﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Xsl;

namespace ExosXSLT
{
	class Program
	{
		static void Main(string[] args)
		{
			bool ok = false;
			string chemin = String.Empty;

			while (!ok)
			{
				Console.WriteLine("Chemin de la feuille de styles à appliquer :");
				chemin = Console.ReadLine();

				if (File.Exists(chemin))
					ok = true;
				else
					Console.WriteLine("Chemin non valide");
			}

            // On récupère le répertoire et le nom de la feuille de styles
            string rep = Path.GetDirectoryName(chemin);
			string nom = Path.GetFileNameWithoutExtension(chemin);
			
			// On contruit le chemin du fichier résultat de la transfo
			string resultat = Path.Combine(rep, "Résultat" + nom + ".xml");
            //string resultat = rep + "\\Résultat" + nom + ".xml";

            // On applique la transformation
            XslCompiledTransform trans = new XslCompiledTransform();
			trans.Load(chemin);
			trans.Transform(@"..\..\CollectionsBD.xml", resultat);
			Console.WriteLine("Fichier résultat prêt");

			Console.ReadKey();
		}
	}
}
